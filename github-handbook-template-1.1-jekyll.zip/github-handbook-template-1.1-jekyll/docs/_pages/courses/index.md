---
#July 20, 2020
#
# Editable - Title and Description display on the page and in HTML meta tags
#
title: Courses
#
# Don't edit items below - they control the page layout
#
return-top: yes
layout: page
page-description: yes
permalink: /courses
#
---
## Courses

Home Page link should redirect to: <a href="https://lab.gihub.com">GitHub Learning Lab</a>.

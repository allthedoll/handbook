---
#
# Editable - Title and Description display on the page and in HTML meta tags
#
title: Access Policies
description: Policies and standards around access to the GitHub organization.  
#
# Don't edit items below - they control the page layout
#
return-top: yes
layout: page
page-type: subpage
page-description: yes
permalink: /policies/access-policies
#
---

Company policies could be listed here.

---
Return to [Policies and Standards]({{ site.baseurl }}/policies)

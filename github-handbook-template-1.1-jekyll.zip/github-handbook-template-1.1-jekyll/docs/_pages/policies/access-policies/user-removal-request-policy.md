---
title: User Removal Request Policy
permalink: /remove-users
layout: page
page-type: subpage  
---

<!--
    This page is something the company needs to determine if it's needed or not.
    If a code of conduct already exists you can link to it by adding the url to the url section above.
    If a code of conduct doesn't exists this file can be used to create it.
-->
<!-- These are suggestions of tools. The company should consider if this is a policy they want to follow -->

---

User removal policy would go here.

---
Return to [Policies and Standards]({{ site.baseurl }}/policies)

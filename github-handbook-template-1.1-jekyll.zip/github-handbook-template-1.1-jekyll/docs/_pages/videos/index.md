---
#
# Editable - Title and Description display on the page and in HTML meta tags
#
title: Videos
page-description: yes
description: Videos of past trainings and webinars can help you get started with GitHub. 
return-top: yes
layout: page
page-description: yes
permalink: /videos
#
---

Location of previously recorded trainings and webinars will be listed here.

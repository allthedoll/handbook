---
#
# You can use Markdown in the editable content below the three dashes (---)
#
# Editable - Title and Description display on the page and in HTML meta tags
#
title: Page not found
description: Page not found in the GitHub Handbook.
#
# Don't edit items below - they control the page layout
#
return-top: no
layout: page
page-type: subpage
page-description: yes
permalink: /assets/index.html
#
---

There's no content for this page. Try using the global navigation, or return to the [home page]({{ site.baseurl }}/).

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
